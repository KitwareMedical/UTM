


gwt.iteratedPCA <- function(data, d, epsilon){

#gwtID <- .Call("gwtIteratedPCA",  as.matrix(t(data)), ncol(data), nrow(data),  
#                as.integer(d), as.double(epsilon) )

#  obj <- structure( list(gwtID=gwtID, d=d, epsilon=epsilon), class="gwt",
#subclass="IteratedPCA")

#  obj  
   
}


gwt.project <- function(gwt, data, scale){
#  X <- .Call("gwtProject",  as.integer(gwt$gwtID), as.matrix(t(data)),
#ncol(data), nrow(data), as.integer(scale) )
#  t(X)
}
