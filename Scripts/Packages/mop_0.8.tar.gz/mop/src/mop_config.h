//Which linear programming libraries should be made avaiable. Requires for R to
//have the corresponding libraries on its linker path. Currently lemon is used
//which is included in the package. If you want to include another library
//uncomment and adjust the linker arguments in Makevars.



//#define MOP_USE_CPLEX
//#define MOP_USE_MOSEK
//#define MOP_USE_GLPK



//#define VERBOSE
